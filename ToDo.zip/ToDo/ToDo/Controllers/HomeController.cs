﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ToDo.Controllers
{
    public class HomeController : Controller
    {
        List<ToDo.Models.ToDoList> listaToDo = new List<Models.ToDoList>();

        public ActionResult Index()
        {
            return View("Index");
        }

        public void CrearToDo()
        {
            ToDo.Models.ToDoList unaLista = new Models.ToDoList();
            unaLista.Fecha = DateTime.Now;
        }

        public void AgregarItem(int pos)
        {
            if(listaToDo[pos].items.Count < 5)
                listaToDo[pos].items.Add(new Models.ToDoItem());
        }
    }
}
